// components/Tabs/Tabs.js
Component({
  /**
   * 存的数据是要从父组件接收的数据
   */
  properties: {
    // aaa:{
    //   type:String,//接收数据的类型
    //   value:""//默认值
    // }
    tabs:{
      type:Array,
      value:[]
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    
  },

  /**
   * 组件的方法列表
   * 1 页面.js文件中存放时间回调函数的时候是存放在data同层级下
   * 2 组件.js文件中存放时间回调函数的时候必须存放在methods下
   */
  methods: {
    hanIdItemTap(e){
      const {index}=e.currentTarget.dataset;//获取索引

      //点击事件触发的时候，触发父组件中的自定义事件，同时传递数据给父组件
      //this.triggerEvent("父组件自定义事件的名称",要传递的参数)
      this.triggerEvent("itemChange",{index});
      // let {tabs}=this.data;//获取data中的数据
      
      //循环数组 v代表tabs中的数据，可直接修改tabs中的数据
      // tabs.forEach((v,i) =>i==index?v.isActive=true:v.isActive=false);
      
      // this.setData({
      //   tabs
      // })

    }
  }
})
