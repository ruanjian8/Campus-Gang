// pages/demo2/demo2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[//物品数据
    ],
  


    
    tabs:[//下边框数据
      {
        id:0,
        name:"全部发帖",
        isActive:true
      },
      {
        id:1,
        name:"回应贴",
        isActive:false
      }
    ],
    list1:[//物品数据
    ],
  /**
   * 页面的初始数据
   */
    selectShow: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectData: ['发帖类型','遗失贴','失物贴'],//下拉列表的数据
    index: 0,//类型下拉框的选择
    Show: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    Data: ['时间','今天','昨天','一周内','更久'],//下拉列表的数据
    num:0,//时间下拉框的选择
    showDialog: false,
    time:0,
    type:0,
    time1:0,
    time_stap:0,
    miaoshu:"最近一次登录时间",
    id:"",
    showModal:true,
    scrollH: 0,
    imgWidth: 0,
    loadingCount: 0,
    images: [],
    col1: [],
    col2: [],
    TimeId:-1//设置一个定时器
  },


  
onLoad:function(e){
  var self=this;
  wx.login({
      success: res => {
          // 获取到用户的 code 之后：res.code
          
          // 可以传给后台，再经过解析获取用户的 openid
          // 或者可以直接使用微信的提供的接口直接获取 openid ，方法如下：
          wx.request({
              // 自行补上自己的 APPID 和 SECRET
              url: 'https://api.weixin.qq.com/sns/jscode2session?appid=wx6e11a12c89c6d4c6&secret=691f07b1ea80fffac9458e20bb4009cd&js_code=' + res.code + '&grant_type=authorization_code',
              success: res => {
                  // 获取到用户的 openid
                self.setData({
                  openid:res.data.openid
                })
              }
          });
      }
  });

  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/index',
    method:'GET',
    header:{'Content-Type':'application/json'},
    data:{},
    success:function(res){
      for (var i=0;i<res.data.length;i++){
        var img1 = res.data[i]['img'].split('|')
        var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        res.data[i]['img']=img1
        res.data[i]['datatime']=time3
      }
      self.setData({
        list: res.data,
      })
    },
    
  })
},

//搜索
onShow:function() {
  var self=this;
  //对输入学号进行判断
 if((self.data.id.length!=0)&&(self.data.id.length == 9)){
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/search1',
      method: 'GET',
      data:{ id:this.data.id },
      header: {
        'content-type': 'application/json'
      },  
      success:function(res){
        for (var i=0;i<res.data.length;i++){
          var img1 = res.data[i]['img'].split('|')
          var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
          var time2=parseInt(time1/1000)
          if(time2<=3600){//分钟
            var time3=parseInt(time2/60)+"分"
          }
          else if(3600<time2&&time2<=86400){
            var time3=parseInt(time2/3600)+"时"
          }else{
            var time3=parseInt(time2/3600/24)+"天"
          }
          res.data[i]['img']=img1
          res.data[i]['datatime']=time3
        }
        self.setData({
          list:res.data
        })
      }          
    })
  }
  if(self.data.id.length==0){
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/index',
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },  
      success:function(res){
        for (var i=0;i<res.data.length;i++){
          var img1 = res.data[i]['img'].split('|')
          var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
          var time2=parseInt(time1/1000)
          if(time2<=3600){//分钟
            var time3=parseInt(time2/60)+"分"
          }
          else if(3600<time2&&time2<=86400){
            var time3=parseInt(time2/3600)+"时"
          }else{
            var time3=parseInt(time2/3600/24)+"天"
          }
          res.data[i]['img']=img1
          res.data[i]['datatime']=time3
        }
        self.setData({
          list:res.data
        })
      }          
    })
  } 
},
//数据请求
userInput: function(e) {  
  var id=e.detail.value;//获取搜索框的内容
  clearTimeout(this.TimeId);//清除定时器     
  this.TimeId=setTimeout(()=>{//重新设置搜索时间
    if((id.length!=9)&&(id.length!=0)){
      console.log("学号错误");
    }
    else{
      this.onShow();
    }
  },1500) ; 
  this.setData({//改变id值
    id:id
  })
  let that = this;
  wx.request({
    url: 'http://localhost:90/tp5/public/Index.php/index/Guangchang/search1',
    method: 'GET',
    data: {
      id: id,
    },
    header: {
      'content-type': 'application/json'
    },    
    success(res) {
      for (var i=0;i<res.data.length;i++){
        var img1 = res.data[i]['img'].split('|')
        var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        res.data[i]['img']=img1
        res.data[i]['datatime']=time3
      }
      that.setData({
        list: res.data
      })
    }   
  })
},

select() {
  this.setData({
    Show: !this.data.Show
  });
},
// 点击下拉列表

   // 点击下拉显示框
 selectTap() {
  this.setData({
    selectShow: !this.data.selectShow
  });
},
// 点击下拉列表
optionTap(e) {
  var self = this;
  let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
  this.setData({
    type: Index,
    selectShow: !this.data.selectShow
  });
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/type',//php/方法
    data:{
      type:self.data.type,
      time:self.data.time,
    },
    method: 'GET',
    header: {
      'content-type': 'application/json'
    },
    success: function (res) {
      for (var i=0;i<res.data.length;i++){
        var img1 = res.data[i]['img'].split('|')
        var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        res.data[i]['img']=img1
        res.data[i]['datatime']=time3  
      }
        self.setData({
          list:res.data,
        });
    },
  })
},
// 点击下拉显示框
select() {
  this.setData({
    Show: !this.data.Show
  });
},
// 点击下拉列表
option(e) {
  var self = this;
  let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
  this.setData({
    time: Index,
    Show: !this.data.Show
  });
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/type',//php/方法
    data:{
      time:self.data.time,
      type:self.data.type,
    },
    method: 'GET',
    header: {
      'content-type': 'application/json'
    },
    success: function (res) {
      for (var i=0;i<res.data.length;i++){
        var img1 = res.data[i]['img'].split('|')
        var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        res.data[i]['img']=img1
        res.data[i]['datatime']=time3   
      }
        self.setData({
          list:res.data,
        });
    },
  })
},
onPullDownRefresh: function () {
  
  this.setData({
    time:0,
    type:0,
    biao:""
  })
  this.onLoad();
}
})