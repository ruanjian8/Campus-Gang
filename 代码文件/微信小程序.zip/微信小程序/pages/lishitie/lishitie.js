Page({
  data:{
    tie_id:1,
    sno : 211706135,
    hui_sno : 211706127,
    openid:'433',
  },
  onLoad: function (options) {
    var sno = options.sno;
    var tie_id = options.tie_id;
    // var hui_sno = options.hui_sno;
    // var openid = options.openid;
    var self =this;
    this.setData({
      sno:sno,
      tie_id:tie_id,
      // hui_sno:hui_sno,
      // openid :openid
    }),
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishitie/index',//获取帖子相关信息
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{
        tie_id:this.data.tie_id,
        sno:this.data.sno
      },
      success: function (res) {
        self.setData({
          list1:res.data,
        });
        //console.log(res.data)

        wx.request({
          url: 'http://localhost:90/tp5/public/index.php/index/Lishitie/get_user_info',//获取发帖人信息
          method: 'GET',
          header: {
            'content-type': 'application/json'
          },
          data:{
            sno:res.data[0].sno
          },
          success: function (res) {
            self.setData({
              list2:res.data,
            });
          },
        })
      },
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishitie/get_op_info',//获取操作员信息
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{
        tie_id:this.data.tie_id,
      },
      success: function (res) {
        //console.log(res),
        self.setData({
          list3:res.data,
        });
      },
    })
    var self =this;
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishitie/get_qes',//获取回复贴的问题及回答
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{
        sno:this.data.sno,
        tie_id:this.data.tie_id,
      },
      success: function (res) {
        //console.log(res),
        self.setData({
          tabs:res.data,
        });
        //console.log(res.data)
      },
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishitie/get_img',//获取帖子的轮播图
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{tie_id:this.data.tie_id},
      success: function (res) {
        //console.log(res),
        self.setData({
          list4:res.data,
        });
      },
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishitie/time',//获取发帖时间
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{
        sno:this.data.sno,
        tie_id:this.data.tie_id,
      },
      success: function (res) {
        var time1=Date.parse(new Date())-Date.parse(res.data[0]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        //console.log(res),
        self.setData({
          time2:time3
        });
      },
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishitie/hui_time',//获取回复时间
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{
        sno:this.data.sno,
        tie_id : this.data.tie_id
      },
      success: function (res) {
        self.setData({
          hui_time:res.data,
        });
      },
    })
  },
})
// 导入数据库的数据