// pages/demo02/demo02.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    head:"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1590950394700&di=a2be2dbc3d2e93e7ecdb936d9ac5b061&imgtype=0&src=http%3A%2F%2Fstatic.zuidaima.com%2Fimages%2F156725%2F201701%2F20170103222050034.jpg",
    openid:"123",
    tie_id:1,
    show:1,
    sno:211,
    title:"17计科的学生卡",
    type:"#校园卡#",
    stype:"未找到",
    user_name:"用户名",
    send_time:"01-30 12：12",
    main_text:"内容部分",
    tag:null,
    wenti:[{
      id:1,
      ans:"测试成功",
      wen:"问题1"
    },
    {
      id:2,
      ans:"测试成功",
      wen:"问题2"
    },
    {
      id:3,
      ans:"测试成功",
      wen:"问题3"
    }],
    list:[]
  },
  bindletop(e){//将点击过后的值传给此函数
    const operation = e.currentTarget.dataset.operation;//读取e中的值bin传给operation
    if (this.data.tag == null){
      wx.showModal({
        title: '提示',
        content: '你需要先进行注册才能想申请找回',
        showCancel:false,
      })
    }
    else if(this.data.tag != null){
      this.setData({
        show:operation//改变值初始值
      })
    }

  },
  showup(e){
    const operation = e.currentTarget.dataset.operation;//读取e中的值bin传给operation
    this.setData({
    show:operation//改变值初始值
    })
  },
  showup1(e){
    const operation = e.currentTarget.dataset.operation;//读取e中的值bin传给operation
    const wenti = this.data.wenti;
    // var respond_1=this.data.wenti[0].ans;
    // var respond_2=this.data.wenti[1].ans;
    // var respond_3=this.data.wenti[2].ans;
    let self=this
    var i=0;
    var num=0;
    for(i;i<this.data.wenti.length;i++){
      if(this.data.wenti[i].ans==null||this.data.wenti[i].ans.length==0){
        wx.showModal({
          title: '提示',
          content: '回答不能为空！',
          showCancel:false,
          success (res) {
            if (res.confirm) {
              // console.log('用户点击确定')
            }
          }
        })
        num=1;
        break;
      }
    }
    if(num==0){
      wx.request({
        url: 'http://localhost:90/tp5/public/index.php/index/Xiangxi/upload_ans',
        method: 'GET',
        header: {'Content-Type': 'application/json'},
        
        data: {
          // respond_1,
          // respond_2,
          // respond_3,
          wenti:wenti,
          tie_id:self.data.tie_id,
          sno:self.data.tag.sno
        },
        success(res){
          console.log(res.data+"   02")
          console.log(self.data.wenti[0].ans)
        },
      })
      wx.showModal({
          title: '结果',
          content: '提交成功，请耐心等待审核。',
          showCancel:false,
          success (res) {
            if (res.confirm) {
              // console.log(wenti)
              var show=1
              self.setData({
                show
              })
            }
          }, 
      })
    }
  },
  closeall(e){
    const operation = e.currentTarget.dataset.operation;
    this.setData({
      show:operation
    })
  },
  talks(e){
    let item = e.currentTarget.dataset.model;
    let use = 'wenti['+item+'].ans';
    let wenti = 'wenti';
    this.setData({
      [use]: e.detail.value
    })
  },
  

onLoad: function (options) {
  var tie_id = options.tie_id;
    var openid = options.openid;
    this.setData({
      tie_id:tie_id,
      openid : openid
  })
  wx.showLoading({
    title: '加载中',
    mask:true
  })
  var that = this;
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Xiangxi/index',//此处填写你后台请求地址
    method: 'GET',
    header: {'Content-Type': 'application/json'},
    data: {tie_id:this.data.tie_id},
    success: function (res) {
      // console.log(res.data);//打印请求返回的结果
      res.data[0].datatime
        that.setData({
          title:res.data[0].title,
          type:"#"+res.data[0].keyword+"#",
          stype:res.data[0].type,
          user_name:res.data[0].name,
          send_time:res.data[0].datatime,
          main_text:res.data[0].text,
          sno : res.data[0].sno,
        })
        wx.request({
          url: 'http://localhost:90/tp5/public/index.php/index/Xiangxi/get_openid',
          method:'GET',
          header: {'Content-Type': 'application/json'},
          data: {
            sno:res.data[0].sno
          },
          success:function(res){
            that.setData({
              head:res.data[0].wechat_avatar
            })
            
          }
        })
      }, 
  })
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Xiangxi/get_qes',//此处填写你后台请求地址
    method: 'GET',
    header: {'Content-Type': 'application/json'},
    data: {tie_id:this.data.tie_id},
    success: function (res) {
      // console.log(res.data);//打印请求返回的结果
      res.data[0].datatime
        that.setData({
          wenti:res.data
        })
      },
  }),
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Xiangxi/get_img_url',//此处填写你后台请求地址
    method: 'GET',
    header: {'Content-Type': 'application/json'},
    data: {tie_id:this.data.tie_id},
    success: function (res) {
      // console.log(res.data);//打印请求返回的结果
      res.data[0].datatime
        that.setData({
          list:res.data
        })
      },

  })
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Xiangxi/test_only',
    method: 'GET',
    header: {'Content-Type': 'application/json'},
    data:{
      openid:that.data.openid
    },
    success(result){
      that.setData({
        tag:result.data[0]
      })
      console.log(result.data[0])
      wx.hideLoading();
    }
  })

},
})