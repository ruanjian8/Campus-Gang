// pages/history/history.js
Page({
  data: {
    tabs:[//下边框数据
      {
        id:0,
        name:"历史完成贴",
        isActive:true
      },
      {
        id:1,
        name:"历史操作",
        isActive:false
      }
    ],
    list:[//物品数据
      // {
      //   tie_id:0,
      //   id: 211706111,
      //   number: 0,
      //   class: "red",
      //   style:'遗失贴',
      // },
      // {
      //   tie_id:1,
      //   id: 211706124,
      //   number: 0,
      //   class: "red",
      //   style:'遗失贴',
      // },
      // {
      //   tie_id:2,
      //   id: 211706141,
      //   number: 1,
      //   class: "green",
      //   style:'失物贴',
      // }
    ],
    list1:[//物品数据
      // {
      //   id:211706121,
      //   name: "XX",
      // },
      // {
      //   id:211706127,
      //   name: "XXX",
      // },
      // {
      //   id:211706125,
      //   name: "XX",
      // }
    ],
    time:0,
    type:0,
    selectShow: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectData: ['发帖类型','遗失贴','失物贴'],//下拉列表的数据
    index: 0,//选择的下拉列表下标
    Show: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    Data: ['时间','今天','昨天','一周内','更久'],//下拉列表的数据
    num:0
  },
  // 点击下拉显示框
  selectTap() {
    this.setData({
      selectShow: !this.data.selectShow
    }); 
  },
  // 点击下拉列表
  optionTap(e) {
    var self = this;
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    self.setData({
      type: Index,
      selectShow: !this.data.selectShow
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/History/type',
      data: {
        type:self.data.type,
        time:self.data.time,
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    })
  },
  // 点击下拉显示框
  select() {
    this.setData({
      Show: !this.data.Show
    });
  },
  // 点击下拉列表
  option(e) {
    var self = this;
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    self.setData({
      time: Index,
      Show: !this.data.Show
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/History/type',
      data: {
        time:self.data.time,
        type:self.data.type,
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    })
  },
  onLoad: function (e) {
    var self = this;
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/History/caozuo',
      data: {
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/History/caozuo1',
      data: {
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         List1:res.data,
        }) 
      }
    })
  },
  // 自定义事件，用来接收子组件传递的数据
  handleItemChange(e){
    const {index} = e.detail;
    let {tabs} = this.data;
    tabs.forEach((v,i) =>i==index?v.isActive=true:v.isActive=false);
    this.setData({
      tabs
    })
  },
  onPullDownRefresh: function () {
    this.setData({
      time:0,
      type:0,
    })
    this.onLoad();
  }
})