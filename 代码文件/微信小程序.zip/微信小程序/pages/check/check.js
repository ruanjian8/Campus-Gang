// pages/check/check.js
Page({
  data: {
    list:[],
    zhuangtai:0,
    selectShow: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectData: ['发帖类型','遗失贴','失物贴'],//下拉列表的数据
    index: 0,//贴字类型选择的下拉列表下标
    Show: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    Data: ['审核状态','驳回','通过','未审核'],//下拉列表的数据  
    type:0,
    url:"/pages/shenhe/shenhe",
    url1:""
  },
  onLoad:function(options){
    var self = this;
    var openid=options.openid 
    self.setData({
      openid:openid
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Check/index',
      data: {
        openid:self.data.openid
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    })
  },
  onPullDownRefresh: function () {
    var self = this;
    self.setData({
      time:0,
      type:0
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Check/index',
      data: {
        openid:self.data.openid
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    })
  },


  // 点击下拉显示框
  selectTap() {
    this.setData({
      selectShow: !this.data.selectShow
    });
  },
  // 点击下拉列表
  optionTap(e) {
    var self = this;
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    self.setData({
      type: Index,
      selectShow: !this.data.selectShow
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Check/type',
      data: {
        type:self.data.type,
        zhuangtai:self.data.zhuangtai,
        openid:self.data.openid
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    })
  }, 
  option(e) {
    var self = this;
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    self.setData({
      zhuangtai: Index,
      Show: !this.data.Show
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Check/type',
      data: {
        zhuangtai:self.data.zhuangtai,
        type:self.data.type,
        openid:self.data.openid
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    })
  },
  // 点击下拉显示框
  select() {
    this.setData({
      Show: !this.data.Show
    });
  },
  // 点击下拉列表
 
// })
  //显示下拉框选择的结果
  handleChange(e){
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    this.setData({
        type:Index
    })   
  }
})