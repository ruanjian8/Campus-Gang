// pages/demo4/demo4.js
Page({
  data: {
    openid:'oe3JI42J5ERRHLzj6RQCxSNRzRi8',
    admin:0,
    guanyu:0,
    lianxi:0,
    logo:"https://camo.githubusercontent.com/e687b99bbc40dc846516faf1d39dfd2c2160063d/68747470733a2f2f696d67323032302e636e626c6f67732e636f6d2f626c6f672f313933303430332f3230323030332f313933303430332d32303230303333313137313632333336362d3835383536363439392e706e67",
    list:[
      {
        "url":"../../pages/goods/goods",
        "src":"https://ae01.alicdn.com/kf/H56e6a620814543d896aa509edb9bc6e1A.jpg",
        "title":"我的发布"
      },
      {
        "url":"../../pages/xuehao/xuehao",
        "src":"https://ae01.alicdn.com/kf/He1a69c8e133c45afa2d50da47b674bb7q.jpg",
        "title":"学号"
      },
      {
        "url":"../../pages/check/check",
        "src":"https://ae01.alicdn.com/kf/H1770d76e9b594055b69d31be451fda7aX.jpg",
        "title":"审核结果"
      },
      {
        "url":"../../pages/user/user",
        "src":"https://ae01.alicdn.com/kf/Ha8b69b3e3ea244bea814b222d5e0c1a6a.jpg",
        "title":"用户信息"
      },
      {
        "url":"../../pages/public/public",
        "src":"https://ae01.alicdn.com/kf/H0de4e2532d3644ef8dbc0b004234cfa9V.jpg",
        "title":"发帖审核"
      },
      {
        "url":"../../pages/guangchang1/guangchang1",
        "src":"https://ae01.alicdn.com/kf/H917c75917280434c911a38187c27a040L.jpg",
        "title":"信息管理"
      },
      {
        "url":"../../pages/history/history",
        "src":"https://ae01.alicdn.com/kf/H3a05a56b3cb34d008512c91102352d08m.jpg",
        "title":"历史"
      }
    ],
    list1:[
      {
        "url":"../../pages/goods/goods",
        "src":"https://ae01.alicdn.com/kf/H56e6a620814543d896aa509edb9bc6e1A.jpg",
        "title":"我的发布"
      },
      {
        "url":"../../pages/xuehao/xuehao",
        "src":"https://ae01.alicdn.com/kf/He1a69c8e133c45afa2d50da47b674bb7q.jpg",
        "title":"学号"
      },
      {
        "url":"../../pages/check/check",
        "src":"https://ae01.alicdn.com/kf/H1770d76e9b594055b69d31be451fda7aX.jpg",
        "title":"审核结果"
      }
    ]
  },
  onLoad: function() {
    var that = this;
    wx.getUserInfo({
        success: function(res) {
            // 用户已经授权过,不需要显示授权页面,所以不需要改变 isHide 的值
            // 根据自己的需求有其他操作再补充
            // 我这里实现的是在用户授权成功后，调用微信的 wx.login 接口，从而获取code
           
            wx.login({
                success: res => {
                    // 获取到用户的 code 之后：res.code
                    
                    // 可以传给后台，再经过解析获取用户的 openid
                    // 或者可以直接使用微信的提供的接口直接获取 openid ，方法如下：
                    wx.request({
                        // 自行补上自己的 APPID 和 SECRET
                        url: 'https://api.weixin.qq.com/sns/jscode2session?appid=wx6e11a12c89c6d4c6&secret=691f07b1ea80fffac9458e20bb4009cd&js_code=' + res.code + '&grant_type=authorization_code',
                        success: res => {
                            // 获取到用户的 openid
                            console.log("用户的openid:" + res.data.openid);
                           that.setData({
                              openid:res.data.openid
                           })
                        }
                    });
                    wx.request({
                      url: 'http://localhost:90/tp5/public/index.php/index/Xuehao/index',//php/方法
                      data:{
                        openid:that.data.openid
                      },
                      method: 'GET',
                      header: {
                        'content-type': 'application/json'
                      },
                      success: function (res) {
                        that.setData({
                          admin:res.data,
                        });
                      }
                    });
                }
            });
        }
        
    });
  },
  lianxi(e){
    this.setData({
      lianxi:1
    })
  },
  guanyu(e){
    this.setData({
      guanyu:1
    })
  },
  yincang(e){
    console.log(e.target.dataset.index);
    var index = e.target.dataset.index
    this.setData({
      [index]:0
    })
  }

})
