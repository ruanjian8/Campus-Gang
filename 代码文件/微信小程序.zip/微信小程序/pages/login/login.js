
Page({
  data: {
      //判断小程序的API，回调，参数，组件等是否在当前版本可用。
      canIUse: wx.canIUse('button.open-type.getUserInfo'),
      isHide: false,
      logo:"https://camo.githubusercontent.com/e687b99bbc40dc846516faf1d39dfd2c2160063d/68747470733a2f2f696d67323032302e636e626c6f67732e636f6d2f626c6f672f313933303430332f3230323030332f313933303430332d32303230303333313137313632333336362d3835383536363439392e706e67",
  },

  onLoad: function() {
      var that = this;
      // 查看是否授权
      wx.getSetting({
          success: function(res) {
              if (res.authSetting['scope.userInfo']) {
                  wx.getUserInfo({
                      success: function(res) {
                        wx.switchTab({
                            url: '../../pages/guangchang2/guangchang2',
                        });
                      }
                      
                  });
              } else {
                  // 用户没有授权
                  // 改变 isHide 的值，显示授权页面
                  that.setData({
                      isHide: true
                  });
              }
          }
      });
  },
  bindGetUserInfo: function(e) {
      if (e.detail.userInfo) {
          //用户按了允许授权按钮
          var that = this;
          wx.switchTab({
            url: '../../pages/guangchang2/guangchang2',
          });
      } else {
          //用户按了拒绝按钮
          wx.showModal({
              title: '警告',
              content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入。',
              showCancel: false,
              confirmText: '返回授权',
              success: function(res) {
                  // 用户没有授权成功，不需要改变 isHide 的值
                  if (res.confirm) {
                      console.log('用户点击了“返回授权”');
                  }
              }
          });
      }
  }
})