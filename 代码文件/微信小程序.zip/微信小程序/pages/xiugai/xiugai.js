// pages/demo/demo.js
//获取应用实例
const app = getApp()
var util = require('../../utils/util.js')
Page({
  data: {
    num:0,
    uploaderList:[],/**已选择的图片临时路径数组*/
    showUpload:true,/**用来判断是否可继续选择图片,当传至9张时不可继续上传*/
    inputValue_question:[],/**存放特征问题 */
    empty:[1,1,1,1,1,1],
    focusId: "",
    inputValue_answer:[],/**存放答案 */
    aaaa:"详细描述....(时间地点等)"
  },
    // 删除图片
    clearImg:function(e){
        var that=this;
        var nowList = [];//新数据
        var uploaderList = this.data.uploaderList;//原数据
        var uploaderNum=this.data.uploaderList.length;
        for (let i = 0; i < uploaderList.length;i++){
            if (i == e.currentTarget.dataset.index){
                continue;
            }else{
                nowList.push(uploaderList[i])
            }
        }
        this.setData({
            uploaderNum: uploaderNum - 1,
            uploaderList: nowList,
            showUpload: true
        })
    },
  //展示图片
    showImg:function(e){
        console.log(e)
        var that=this;
        var uploaderList = this.data.uploaderList;//原数据
        var index=e.currentTarget.dataset.index;
        var uploaderNum=this.data.uploaderList.length;
        wx.previewImage({
            urls:uploaderList,
            current: uploaderList[index]
        })
    },
    //上传图片
    upload: function(e) {
        var that = this;
        var uploaderNum=this.data.uploaderList.length;
        wx.chooseImage({
            count: 9 - uploaderNum, // 默认9
            sizeType: ['original', 'cosspressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function(res) {
                console.log(res)
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
                var tempFilePaths = res.tempFilePaths;
                let uploaderList=that.data.uploaderList.concat(tempFilePaths)
                if (uploaderList.length==9){
                    that.setData({
                        showUpload:false
                    })
                }
                that.setData({
                    uploaderList:uploaderList,
                })
            }
        }) 
    }, 
    inputBlur_title:function(e){//标题改变时
        let title="empty["+0+"]"
        if(e.detail.value==null){
            wx.showModal({
                title: '提示',
                content: '标题不能为空',
                showCancel: true,
                cancelText: '取消',
                cancelColor: '#000000',
                confirmText: '确定',
                confirmColor: '#3CC51F',
                success: (res) => {
                    if(res.confirm){
                        console.log("用户点击确定")
                    }
                    else if(res.cancel){
                        console.log("用户点击取消")
                    }
                },
            });
            this.setData({
                    [title]:0
            })
        }
        if(e.detail.value != null){
            if(e.detail.value.length==0){
                wx.showModal({
                title: '提示',
                content: '标题不能为空',
                showCancel: true,
                cancelText: '取消',
                cancelColor: '#000000',
                confirmText: '确定',
                confirmColor: '#3CC51F',
                success: (res) => {
                    if(res.confirm){
                        console.log("用户点击确定")
                    }
                    else if(res.cancel){
                        console.log("用户点击取消")
                    }
                }
                });
                this.setData({
                    [title]:0
                })
            }
        }
        if((e.detail.value != null)&&(e.detail.value.length!=0)){
            this.setData({
                "revise_input[0].title":e.detail.value,
            })
        }
        console.log("标题：",this.data.revise_input[0].title)
    },
    inputBlur_text:function(e){//物品描述改变时
        let title="empty["+1+"]"
        if(e.detail.value!=null){
            if(e.detail.value.length==0){
                wx:wx.showModal({
                    title: '提示',
                    content: '物品描述不能为空',
                    showCancel: true,
                    cancelText: '取消',
                    cancelColor: '#000000',
                    confirmText: '确定',
                    confirmColor: '#3CC51F',
                    success: (res) => {
                        if(res.confirm){
                            console.log("用户点击确定")
                        }
                        else if(res.cancel){
                        console.log("用户点击取消")
                        }
                    },
                });
                this.setData({
                    [title]:0
                })
            }
        }
        if(e.detail.value==null){
            wx:wx.showModal({
                title: '提示',
                content: '物品描述不能为空',
                showCancel: true,
                cancelText: '取消',
                cancelColor: '#000000',
                confirmText: '确定',
                confirmColor: '#3CC51F',
                success: (res) => {
                    if(res.confirm){
                        console.log("用户点击确定")
                    }
                    else if(res.cancel){
                    console.log("用户点击取消")
                    }
                },
            });
            this.setData({
                [title]:0
            })
        }
        if((e.detail.value != null)&&(e.detail.value.length!=0)){
            this.setData({
                "revise_input[0].text":e.detail.value,
            })
        }   
            console.log("物品描述：",this.data.revise_input[0].text)
    },
    inputBlur_keywords:function(e){//关键字改变时
        let title="empty["+2+"]"
        if(e.detail.value !=null){
            if(e.detail.value.length==0){
                wx:wx.showModal({
                    title: '提示',
                    content: '关键字不能为空',
                    showCancel: true,
                    cancelText: '取消',
                    cancelColor: '#000000',
                    confirmText: '确定',
                    confirmColor: '#3CC51F',
                    success: (res) => {
                        if(res.confirm){
                            console.log("用户点击确定")
                        }
                        else if(res.cancel){
                        console.log("用户点击取消")
                        }
                    },
                });
                this.setData({
                    [title]:0
                })
            }
        }
        if(e.detail.value==null){
            wx:wx.showModal({
                title: '提示',
                content: '关键字不能为空',
                showCancel: true,
                cancelText: '取消',
                cancelColor: '#000000',
                confirmText: '确定',
                confirmColor: '#3CC51F',
                success: (res) => {
                    if(res.confirm){
                        console.log("用户点击确定")
                    }
                    else if(res.cancel){
                    console.log("用户点击取消")
                    }
                },
            });
            this.setData({
                [title]:0
            })
        }
        if((e.detail.value != null)&&(e.detail.value.length!=0)){
            this.setData({
                "revise_input[0].keyword":e.detail.value,
            })
        }   
            console.log("关键字：",this.data.revise_input[0].keyword)
    },
    inputBlur_status:function(e){//状态改变时
        let title="empty["+3+"]"
        if(e.detail.value!=null){
            if(e.detail.value.length==0){
                wx:wx.showModal({
                    title: '提示',
                    content: '状态不能为空',
                    showCancel: true,
                    cancelText: '取消',
                    cancelColor: '#000000',
                    confirmText: '确定',
                    confirmColor: '#3CC51F',
                    success: (res) => {
                        if(res.confirm){
                            console.log("用户点击确定")
                        }
                        else if(res.cancel){
                        console.log("用户点击取消")
                        }
                    },
                });
                this.setData({
                    [title]:0
                })
            }
        }
        if(e.detail.value==null){
            wx:wx.showModal({
                title: '提示',
                content: '状态不能为空',
                showCancel: true,
                cancelText: '取消',
                cancelColor: '#000000',
                confirmText: '确定',
                confirmColor: '#3CC51F',
                success: (res) => {
                    if(res.confirm){
                        console.log("用户点击确定")
                    }
                    else if(res.cancel){
                    console.log("用户点击取消")
                    }
                },
            });
            this.setData({
                [title]:0
            })
        }
        if((e.detail.value != null)&&(e.detail.value.length!=0)){
            this.setData({
                "revise_input[0].status":e.detail.value,
            })
        }   
        console.log("状态：",this.data.revise_input[0].status)
    },
    bindFocus_question:function(e){
        var id = e.currentTarget.dataset.id
        this.setData({
            focusId: id
        })
    },
    inputBlur_question:function(e){//特征问题改变时
        var that = this;
        let value = e.detail.value
        let id = e.currentTarget.dataset.id
        console.log(id)
        var updateData = {
            inputValue: value
        }
        updateData["revise_input[0].question["+id+"].value"] = value;
        this.setData({
            ["revise_input[0].question["+id+"]"]:updateData["revise_input[0].question["+id+"].value"]
        })
        console.log("特征问题",id+1,":",updateData["revise_input[0].question["+id+"].value"])
    },
    bindFocus_answer:function(e){
        var id = e.currentTarget.dataset.id
        this.setData({
            focusId: id
        })
    },
    inputBlur_answer:function(e){//答案改变时
        var that = this;
        var value = e.detail.value
        var id = e.currentTarget.dataset.id
        var updateData = {
            inputValue: value
        }
        updateData["revise_input[0].answer["+id+"].value"] = value;
        this.setData({
            ["revise_input[0].answer["+id+"]"]:updateData["revise_input[0].answer["+id+"].value"]
        })
        console.log("答案",id+1,":",updateData["revise_input[0].answer["+id+"].value"])
    },
    laternext: function (e){/*获取发帖类型*/
         this.setData({
            "revise_input[0].type":e.detail.value,
        })
        console.log("类型",this.data.revise_input[0].type)
    },
    submit:function(e){
        var inputValue_question=this.data.revise_input[0].question/**判断特征问题是否为空 */
        var inputValue_answer=this.data.revise_input[0].answer/**判断答案是否为空 */
        var num = this.data.num
        for(var i=0;i<3;i++){
            if((inputValue_question[0]!=null)&&(inputValue_answer[0]!=null)){
                if((inputValue_question[i].length!=0)&&(inputValue_answer[i].length==0)){
                    wx.showModal({
                        title: '提示',
                        content: '题'+(i+1)+'答案不能为空',
                        showCancel: true,
                        cancelText: '取消',
                        cancelColor: '#000000',
                        confirmText: '确定',
                        confirmColor: '#3CC51F',
                        success: (res) => {
                            if(res.confirm){
                                console.log("用户点击确定")
                            }
                            else if(res.cancel){
                            console.log("用户点击取消")
                            }
                        },
                    });
                    num=1;
                    break;
                }
                if((inputValue_question[i].length==0)&&(inputValue_answer[i].length!=0)){
                    wx.showModal({
                        title: '提示',
                        content: '题'+(i+1)+'问题不能为空1',
                        showCancel: true,
                        cancelText: '取消',
                        cancelColor: '#000000',
                        confirmText: '确定',
                        confirmColor: '#3CC51F',
                        success: (res) => {
                            if(res.confirm){
                                console.log("用户点击确定")
                            }
                            else if(res.cancel){
                            console.log("用户点击取消")
                            }
                        },
                    });
                    num=1;
                    break;
                }
            }
            if((inputValue_question[i]==null)&&(inputValue_answer[i]!=null)){
                if(inputValue_answer[i].length!=0){
                    wx.showModal({
                        title: '提示',
                        content: '题'+(i+1)+'问题不能为空',
                        showCancel: true,
                        cancelText: '取消',
                        cancelColor: '#000000',
                        confirmText: '确定',
                        confirmColor: '#3CC51F',
                        success: (res) => {
                            if(res.confirm){
                                console.log("用户点击确定")
                            }
                            else if(res.cancel){
                            console.log("用户点击取消")
                            }
                        },
                    });
                    num=1;
                    break;
                }
            }
            if((inputValue_question[i]!=null)&&(inputValue_answer[i]==null)){
                if(inputValue_question[i].length==0){
                    wx.showModal({
                        title: '提示',
                        content: '题'+(i+1)+'答案不能为空',
                        showCancel: true,
                        cancelText: '取消',
                        cancelColor: '#000000',
                        confirmText: '确定',
                        confirmColor: '#3CC51F',
                        success: (res) => {
                            if(res.confirm){
                                console.log("用户点击确定")
                            }
                            else if(res.cancel){
                            console.log("用户点击取消")
                            }
                        },
                    });
                    num=1;
                    break;
                }
            }
            if((inputValue_question[0]==null)&&(inputValue_answer[0]==null))
            {
                wx.showModal({
                    title: '提示',
                    content: '第一题不能为空',
                    showCancel: true,
                    cancelText: '取消',
                    cancelColor: '#000000',
                    confirmText: '确定',
                    confirmColor: '#3CC51F',
                    success: (res) => {
                        if(res.confirm){
                            console.log("用户点击确定")
                        }
                        else if(res.cancel){
                            console.log("用户点击取消")
                        }
                    },
                });
                num=1;
                break;
            }
        }
        var empty=this.data.empty/**判断用户是否还有未填写的值 */
        for(var i=0;i<empty.length;i++){
            if(empty[i]==0){
                break
            }
        }
        if(num==0){/**提交成功 */
            var revise_input =this.data.revise_input[0]
            wx.showModal({
                title: '提示',
                content: '提交成功，请耐心等待管理员审核',
                showCancel: true,
                cancelText: '取消',
                cancelColor: '#000000',
                confirmText: '确定',
                confirmColor: '#3CC51F',
                success: (res) => {
                    var TIME = util.formatTime(new Date());
                    this.setData({
                        time: TIME,
                    });
                    if(res.confirm){
                        console.log("用户点击确定")
                        var uploaderList=this.data.uploaderList
                        var list=uploaderList.join('|')
                        this.setData({
                            "revise_input[0].img":list
                        })
                        wx.navigateBack({
                            delta:1
                        })

                        wx.request({
                            url: 'http://localhost:90/tp5/public/index.php/index/Xiugai/up',
                            data: {
                                tie_id: revise_input.tie_id,
                                title:revise_input.title,
                                text:revise_input.text,
                                img:revise_input.img,
                                keyword:revise_input.keyword,
                                type:revise_input.type,
                                question_1:revise_input.question[0],
                                question_2:revise_input.question[1],
                                question_3:revise_input.question[2],
                                answer_1:revise_input.answer[0],
                                answer_2:revise_input.answer[1],
                                answer_3:revise_input.answer[2],
                                datatime:TIME
                            },
                            method: 'GET',
                            header: {
                            'content-type': 'application/json'
                            },
                            success: function (res) {
                                console.log(res.data)
                            },
                        })
                    }
                    else if(res.cancel){
                     console.log("用户点击取消")
                    }
                },
            }); 
        }
    },
    onLoad: function (options) {
        var that=this
        var tie_id = options.tie_id;
        let tie = 'revise_input.tie_id'
        this.setData({
          [tie]:tie_id
        })
        //加载网页时在数据库中按照帖子编码在数据库中查找，并传到前端
        wx.request({
            url: 'http://localhost:90/tp5/public/index.php/index/Xiugai/index',
            data: {
                tie_id:tie_id,
            },
            method: 'GET',
            header: {
            'content-type': 'application/json'
            },
            success: function (res) {
                console.log(res.data[0])
                that.setData({
                    revise_input: res.data,
                });
                //将特征问题放到数组que中
                var que=[]
                que.push([res.data[0].question_1,res.data[0].question_2,res.data[0].question_3])
                that.data.revise_input[0]["question"]=que[0]
                that.setData({
                    question: que[0]
                });
                //将答案放到数组ans中
                var ans=[]
                ans.push([res.data[0].answer_1,res.data[0].answer_2,res.data[0].answer_3])
                that.data.revise_input[0]["answer"]=ans[0]
                that.setData({
                    answer: ans[0]
                });
                //对img进行分割
                var img=that.data.revise_input[0].img.split('|');
                var uploaderList=that.data.uploaderList
                that.setData({
                    uploaderList:img
                });
            }
        })
    },
});