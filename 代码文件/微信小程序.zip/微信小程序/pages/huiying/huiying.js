Page({
  data: {
  },
  onLoad: function (options) {
    var self =this;
    var hui_sno = options.hui_sno;
    var tie_id = options.tie_id;
    var openid = options.openid;
    this.setData({
      hui_sno,
      tie_id:tie_id,
      openid
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Huiying/index',//获取未审核的帖子的信息
      method: 'GET',
      header: {'content-type': 'application/json'},
      data:{
        hui_sno:this.data.hui_sno,
        tie_id:this.data.tie_id,
      },
      success: function (res) {
        self.setData({
          list1:res.data,
        });
        wx.request({
          url: 'http://localhost:90/tp5/public/index.php/index/Huiying/get_sender_img',//获取回复人的头像及微信名
          method: 'GET',
          header: {'content-type': 'application/json'},
          data:{
            hui_sno:res.data[0].sno
          },
          success(res){
            self.setData({
              Wechat_name:res.data[0].Wechat_name,
              wechat_avatar:res.data[0].wechat_avatar
            })
          }
        })
        wx.request({
          url: 'http://localhost:90/tp5/public/index.php/index/Huiying/get_sender_img',//获取回复人的头像及微信名
          method: 'GET',
          header: {'content-type': 'application/json'},
          data:{
            hui_sno:res.data[0].hui_sno
          },
          success(res){
            self.setData({
              user_name:res.data[0].name
            })
          }
        })
      },
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Huiying/get_qes',//获取回复贴的回答
      method: 'GET',
      header: {'content-type': 'application/json'},
      data:{
        tie_id:this.data.tie_id,
        hui_sno:this.data.hui_sno
      },
      success: function (res) {
        self.setData({
        tabs:res.data,
        });
      },
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Huiying/get_img',//获取轮播图
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{
        tie_id:this.data.tie_id
      },
      success: function (res) {
        self.setData({
          list2:res.data,
        });
      },
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Huiying/time',//获取回复用户上次上线时间
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data: {
        hui_sno:this.data.hui_sno,
        tie_id:this.data.tie_id,
      },
      success: function (res) {
        var time1=Date.parse(new Date())-Date.parse(res.data[0]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        self.setData({
          time1:time3
        });
      },

    })
  },
  tongguo(e){
    var self =this;
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Huiying/tongguo',//获取回复人的头像及微信名
      method: 'GET',
      header: {'content-type': 'application/json'},
      data:{
        tie_id:this.data.tie_id,
        openid:this.data.openid,
        hui_type:this.data.list1[0].hui_type,
        hui_sno:this.data.list1[0].hui_sno,
        sno:this.data.list1[0].sno
      },
      success(res){
        wx.showModal({
          title: '提示',
          content: res.data,
        })
      }
    })
  }
})
// 导入数据库的数据