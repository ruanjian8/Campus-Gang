Page({
  data: {
    num: 0,//设置隐藏弹窗的初始值---符号的弹窗
    nbm: 0,//设置隐藏弹窗的初始值---删除的弹窗
    sno: 0,
    list:[ ],//信息 
    TimeId:-1,
    id:"",
  },

  onLoad:function(options){
    var openid=options.openid 
    this.setData({
      openid:openid
    })
  },
  onPullDownRefresh: function (){
    this.setData({
      biao:""
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/Index.php/index/User/index',
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },   
      success:function(res){
        self.setData({
          list:res.data
        })
      }          
    })
  },

  //刷新数据
  onShow:function() {
    var self=this;
    //对输入学号进行判断
    if((self.data.id.length!=0)&&(self.data.id.length == 9)){//输入框输入学号
      wx.request({
        url: 'http://localhost:90/tp5/public/index.php/index/User/search',
        method: 'GET',
        data:{ id:this.data.id },
        header: {
          'content-type': 'application/json'
        },   
        success:function(res){
          self.setData({
            list:res.data
          })
        }          
      })
    }
    if(self.data.id.length==0){//输入框没有输入学号
      wx.request({
        url: 'http://localhost:90/tp5/public/Index.php/index/User/index',
        method: 'GET',
        header: {
          'content-type': 'application/json'
        },   
        success:function(res){
          self.setData({
            list:res.data
          })
        }          
      })
    } 
  },
  //对输入框输入的学号进行请求
  userInput: function(e) {  
    var id=e.detail.value;//获取搜索框的内容
    clearTimeout(this.TimeId);//清除定时器     
    this.TimeId=setTimeout(()=>{//重新设置搜索时间
      if((id.length!=9)&&(id.length!=0)){
        console.log("学号错误");
      }
      else{
        this.onShow();
      }
    },1500) ; 
    this.setData({//改变id值
      id:id
    })
    let that = this;
    wx.request({
      url: 'http://localhost:90/tp5/public/Index.php/index/User/search',
      method: 'GET',
      data: {
        id: id,//修改id
      },
      header: {
        'content-type': 'application/json'
      },    
      success(res) {
        that.setData({
          list: res.data
        })
      }   
    })
  },

  bindletop(e){//将点击过后的值传给此函数
    const operation = e.currentTarget.dataset.operation;//读取e中的值bin传给operation
    var number= e.currentTarget.dataset.name;//获取item中xxx的值
    this.setData({
      num:operation,//改变值初始值
      sno:number
    })
  },
  //删除数据
  bindRemove(e){
    var number= e.currentTarget.dataset.id;//获取item中xxx的值  
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定要删除吗？',
      success: function (sm) {
        if (sm.confirm) {   
          wx.request({
            url: 'http://localhost:90/tp5/public/Index.php/index/User/reduce',
            data: {
              id: that.data.list[number].sno,
              name:that.data.list[number].name,
              openid:that.data.openid
            },
            method: 'GET',
            header: {
              'content-type': 'application/json'
            }         
          }) 
          that.onShow();   
        }          
      }         
    }) 
  }
})