var app = getApp();
var util = require('../../utils/util.js')
Page({
  data: {
    biaoti:"",
    neirong:"",
    leixing:"",
    guanjian:"",
    list:[
      {
        wenti:"",
        daan:""
      }
    ],
    num:0,
    imgs: [],
    imagePath : 'QQ图片20200503152749.png',
  },


  onLoad: function() {
    var that = this;
    // 查看是否授权
    wx.login({
        success: res => {
            // 获取到用户的 code 之后：res.code
            // 可以传给后台，再经过解析获取用户的 openid
            // 或者可以直接使用微信的提供的接口直接获取 openid ，方法如下：
            wx.request({
                // 自行补上自己的 APPID 和 SECRET
                url: 'https://api.weixin.qq.com/sns/jscode2session?appid=wx6e11a12c89c6d4c6&secret=691f07b1ea80fffac9458e20bb4009cd&js_code=' + res.code + '&grant_type=authorization_code',
                success: res => {
                    // 获取到用户的 openid
                    that.setData({
                      openid:res.data.openid
                    })

                }
            });
        }
    })
  },


  biaoti(e){
    var biaoti = e.detail.value

    this.setData({
      biaoti
    })
  },
  uanjiang(e){
    var guanjiang = e.detail.value

    this.setData({
      guanjiang
    })
  },
  radiochange: function(e) {
            this.setData({
                type
            });
        },
  commentValue(e){
    var neirong = e.detail.value
    this.setData({
      neirong
    })
  },
  chooseImg: function (e) {
    var that = this;
    var imgs = this.data.imgs;
    if (imgs.length >= 9) {
     this.setData({
      lenMore: 1
     });
     setTimeout(function () {
      that.setData({
       lenMore: 0
      });
     }, 2500);
     return false;
    }
    wx.chooseImage({
     // count: 1, // 默认9
     sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
     sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
     success: function (res) {
      // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
      var tempFilePaths = res.tempFilePaths;
      var imgs = that.data.imgs;
      for (var i = 0; i < tempFilePaths.length; i++) {
       if (imgs.length >= 9) {
        that.setData({
         imgs: imgs
        });
        return false;
       } else {
        imgs.push(tempFilePaths[i]);
       }
      }
      that.setData({
       imgs: imgs
      });
     }
    });
   },
   // 删除图片
   deleteImg: function (e) {
    var imgs = this.data.imgs;
    var index = e.currentTarget.dataset.index;
    imgs.splice(index, 1);
    this.setData({
     imgs: imgs
    });
   },
   // 预览图片
   previewImg: function (e) {
    let that = this,
      imgsrc = e.currentTarget.dataset.presrc,
      arr = that.data.upImgArr,
      preArr = [];
    arr.map(function (v, i) {
      preArr.push(v.path)
    })
    wx.previewImage({
      current: imgsrc,
      urls: preArr
    })
  },

  addList: function(){
    var  list = this.data.list;
    var newData = {
      wenti:"",
      daan:""
    };
    var num = this.data.num;
    if(num<2){
      num=num+1;
      list.push(newData);//实质是添加lists数组内容，使for循环多一次
      this.setData({
        list: list,
        num
      }) 
    }
     
  },
  popTest: function(){
    var num = 0;
    if(this.data.biaoti.length==0){
      wx.showModal({
        title: '提示',
        content: '标题不能为空',
        confirmText: '确定',
        confirmColor: '#3CC51F',
        showCancel:false,
        success: (res) => {
            if(res.confirm){
                console.log("用户点击确定")
            }
        }  
      });
      num=1;
    }
    else if(this.data.neirong.length==0){
      wx.showModal({
        title: '提示',
        content: '内容不能为空',
        confirmText: '确定',
        confirmColor: '#3CC51F',
        showCancel:false,
        success: (res) => {
            if(res.confirm){
                console.log("用户点击确定")
            }
        }  
      });
      num=1;
    }
    else if(this.data.imgs.length==0){
      wx.showModal({
        title: '提示',
        content: '最少需要一张图片',
        confirmText: '确定',
        confirmColor: '#3CC51F',
        showCancel:false,
        success: (res) => {
            if(res.confirm){
                console.log("用户点击确定")
            }
        }  
      });
      num=1;
    }
    else if(this.data.guanjian.length==0){
      wx.showModal({
        title: '提示',
        content: '关键词不能为空',
        confirmText: '确定',
        confirmColor: '#3CC51F',
        showCancel:false,
        success: (res) => {
            if(res.confirm){
                console.log("用户点击确定")
            }
        }  
      });
      num=1;
    }
    else if(this.data.leixing.length==0){
      wx.showModal({
        title: '提示',
        content: '要选择类型',
        confirmText: '确定',
        confirmColor: '#3CC51F',
        showCancel:false,
        success: (res) => {
            if(res.confirm){
                console.log("用户点击确定")
            }
        }  
      });
      num=1;
    }
    else{
      var len = this.data.list.length;
      for(var i=0;i<len;i++){
        if(this.data.list[i].daan.length==0||this.data.list[i].wenti.length==0){
          wx.showModal({
            title: '提示',
            content: '问题或答案不能为空。',
            confirmText: '确定',
            confirmColor: '#3CC51F',
            showCancel:false,
            success: (res) => {
                if(res.confirm){
                    console.log("用户点击确定")
                }
            }  
          });
          num=1;
        }
      }
    }
    
    if(num == 0){
      wx:wx.showModal({
        title: '提示',
        content: '确定发布？',
        showCancel: true,
        cancelText: '取消',
        cancelColor: '#000000',
        confirmText: '确定',
        confirmColor: '#3CC51F',
        success: (res) => {
            if(res.confirm){
              var TIME = util.formatTime(new Date());
              var imgs1 = this.data.imgs.join("|");
              this.setData({
                time: TIME,
                imgs1
              });
              
              wx.request({
                url: 'http://localhost:90/tp5/public/index.php/index/Fabu/index',
                data: {
                  title: this.data.biaoti,
                  text: this.data.neirong,
                  img:this.data.imgs1,
                  type:this.data.leixing,
                  keyword:this.data.guanjian,
                  question_1:this.data.list,
                  openid:this.data.openid
                },//获取用户所输入的数据
                method: 'GET',
                header: {
                  'content-type': 'application/json'
                },
              })
              wx.showToast({
                title: '发布成功',
                icon:'success',
                duration: 2000,
              });
              // wx.switchTab({
              //   url: '../../pages/fabu/fabu',
              // });
              this.setData({
                biao:"",
                imgs: [],
              })
            }
            else if(res.cancel){
              console.log("用户点击取消")
            }
        },
      });
    }
     
  },
  previewImg: function (e) {
    var img = this.data.imgPath;
    // 设置预览图片路径
    wx.previewImage({
      current: img,
      urls: [img]
    })
  },
 
  delList: function () {
    var list = this.data.list;
    var num = this.data.num;
    if(num>0){
      num=num-1;
      list.pop();      //实质是删除lists数组内容，使for循环少一次
      this.setData({
        list: list,
        num
      }) 
    }
  },   
  imgYu:function(event){
         var src = event.currentTarget.dataset.src;//获取data-src
        var imgList = event.currentTarget.dataset.list;//获取data-list
       //图片预览
         wx.previewImage({
           current: src, // 当前显示图片的http链接
           urls: imgList // 需要预览的图片http链接列表
        })
      },
  handleChooseAlbum(){
		//系统API，让用户在相册中选择图片（或者拍照）
		wx.chooseImage({
			success : (res) => {
			  //1、取出路径
			  const path = res.tempFilePaths[0]

			  //2、设置imagePath
			  this.setData({
				imagePath : path
			  })
			}
		})
  },
 
  sever: function() {
      let biaoti1 = this.data.biaoti
      let commentValue = this.data.neirong
      if (biaoti1 == ' ') {
         wx.showToast({
          title: '请输入标题'
        })
        return false
      }
      else if (commentValue == ' ') {
        wx: wx.showToast({
          title: '请输入内容'
        })
        return false
      }
      else {
        app.postData("member.address/add", {
          name: name,
          phone: phone
        }, "POST").then(
          res => {
            wx.showToast({
              title: '保存成功',
              icon: 'succes',
              duration: 1000,
              mask: true
            })
          }
        );
      }
  },
  radiochange(e){
    var leixing = e.detail.value
    this.setData({
      leixing
    })
  },
  
  bindblur(e){
    var wenti = e.detail.value
    var id = e.currentTarget.dataset.id
    let wen = 'list['+id+'].wenti'
    this.setData({
      [wen]:wenti
    })
  },
  bindblur1(e){
    var daan = e.detail.value
    var id = e.currentTarget.dataset.id
    let da = 'list['+id+'].daan'
    this.setData({
      [da]:daan
    })
  },
  bindblur2(e){
    var guanjian = e.detail.value
    this.setData({
      guanjian
    })
  },
  onPullDownRefresh: function () {
    this.setData({
      biao:"",
      imgs: [],
    })
  },
})
