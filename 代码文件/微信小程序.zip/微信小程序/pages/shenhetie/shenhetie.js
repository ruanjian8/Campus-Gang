Page({
  data:{
    tie_id:1,
    list3:[],
    que_list:[]
  },
  //展示图片,点击大图
    showImg:function(e){
      let that = this;
      const operation = e.currentTarget.dataset.operation;
      let src = that.data.list2[operation].src;
      wx.previewImage({
        current: src, // 当前显示图片的http链接
        urls: [src] // 
      })
    },
    onLoad: function (options) {
      var sno = options.sno;
      var tie_id = options.tie_id;
      var openid = options.openid;
      this.setData({
        sno,
        tie_id,
        openid
      })
      var self =this;
      wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Shenhetie/index',//获取帖子基本信息
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{
        tie_id:this.data.tie_id,
        sno:this.data.sno
      },
      success: function (res) {
        //console.log(res),
        self.setData({
          list1:res.data,
        });
      wx.request({
        url: 'http://localhost:90/tp5/public/index.php/index/Shenhetie/get_user_info',//获取用户信息
        method: 'GET',
        header: {
          'content-type': 'application/json'
        },
        data:{
          sno:res.data[0].sno
        },
        success: function (res){
          self.setData({
            list3:res.data
          })
        }
      })
      
      }, 
    })
     wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Shenhetie/get_img',//获取发帖图片
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{tie_id:this.data.tie_id},
      success: function (res) {
        //console.log(res),
        self.setData({
        list2:res.data,
        });
      },
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Shenhetie/get_qes',//获取问题列表
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data:{
        tie_id:this.data.tie_id
      },
      success: function (res) {
        //console.log(res),
        self.setData({
        que_list:res.data,
        });
      },
    })
    },
    tongguo(e){
      var self =this;
      wx.request({
        url: 'http://localhost:90/tp5/public/index.php/index/Shenhetie/tongguo',//获取回复人的头像及微信名
        method: 'GET',
        header: {'content-type': 'application/json'},
        data:{
          tie_id:this.data.tie_id,
          openid:this.data.openid,
          hui_type:this.data.list1[0].hui_type,
          sno:this.data.list1[0].sno
        },
        success(res){
          wx.showModal({
            title: '提示',
            content: res.data,
          })
        }
      })
    }
})
// 导入数据库的数