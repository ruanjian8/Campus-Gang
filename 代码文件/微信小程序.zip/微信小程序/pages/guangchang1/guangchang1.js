// pages/demo2/demo2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[//物品数据
    ],
    tabs:[//下边框数据
      {
        id:0,
        name:"全部发帖",
        isActive:true
      },
      {
        id:1,
        name:"回应贴",
        isActive:false
      }
    ],
    list1:[//物品数据
    ],
  /**
   * 页面的初始数据
   */
    selectShow: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectShow1: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectData: ['发帖类型','遗失贴','失物贴'],//下拉列表的数据
    Show: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    Show1: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    Data: ['时间','今天','昨天','一周内','更久'],//下拉列表的数据
    showDialog: false,
    
    type:0,
    time:0,
    type1:0,
    time1:0,
    showModal:true,
    scrollH: 0,
    imgWidth: 0,
    loadingCount: 0,
    images: [],
    col1: [],
    col2: [],
    TimeId:-1,//设置一个定时器
    id:"",
  },

onLoad: function (options) {
  var self = this;
  var openid = options.openid;
  self.setData({
    openid
  })
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Huiyinglie/index',//php/方法
    method: 'GET',
    header: {
      'content-type': 'application/json'
    },
    success: function (res) {
        self.setData({
        list1:res.data,
      });
    },
  });
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/index',
    method:'GET',
    header:{'Content-Type':'application/json'},
    data:{},
    success:function(res){
      for (var i=0;i<res.data.length;i++){
        var img1 = res.data[i]['img'].split('|')
        var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        res.data[i]['img']=img1
        res.data[i]['datatime']=time3
      }
      self.setData({
        list: res.data,
      })
    },
    
  })
},
onShow:function() {
  var self=this;
  //对输入学号进行判断
 if((self.data.id.length!=0)&&(self.data.id.length == 9)){
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/search1',
      method: 'GET',
      data:{ id:this.data.id },
      header: {
        'content-type': 'application/json'
      },  
      success:function(res){
        for (var i=0;i<res.data.length;i++){
          var img1 = res.data[i]['img'].split('|')
          var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
          var time2=parseInt(time1/1000)
          if(time2<=3600){//分钟
            var time3=parseInt(time2/60)+"分"
          }
          else if(3600<time2&&time2<=86400){
            var time3=parseInt(time2/3600)+"时"
          }else{
            var time3=parseInt(time2/3600/24)+"天"
          }
          res.data[i]['img']=img1
          res.data[i]['datatime']=time3       
        }
        self.setData({
          list:res.data
        })
      }          
    })
  }
  if(self.data.id.length==0){
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/index',
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },  
      success:function(res){
        for (var i=0;i<res.data.length;i++){
          var img1 = res.data[i]['img'].split('|')
          var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
          var time2=parseInt(time1/1000)
          if(time2<=3600){//分钟
            var time3=parseInt(time2/60)+"分"
          }
          else if(3600<time2&&time2<=86400){
            var time3=parseInt(time2/3600)+"时"
          }else{
            var time3=parseInt(time2/3600/24)+"天"
          }
          res.data[i]['img']=img1
          res.data[i]['datatime']=time3      
        }
        self.setData({
          list:res.data
        })
      }          
    })
  } 
},
// 点击下拉显示框
selectTap() {
  this.setData({
    selectShow: !this.data.selectShow
  });
},
selectTap1() {
  this.setData({
    selectShow1: !this.data.selectShow1
  });
},
// 点击下拉列表
optionTap(e) {
  var self = this;
  let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
  this.setData({
    type: Index,
    selectShow: !this.data.selectShow
  });
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Huiyinglie/type',//php/方法
    data:{
      type:self.data.type,
      time:self.data.time,
    },
    method: 'GET',
    header: {
      'content-type': 'application/json'
    },
    success: function (res) {
        self.setData({
          list1:res.data,
        });
    },
  })
},
optionTap1(e) {
  var self = this;
  let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
  this.setData({
    type1: Index,
    selectShow1: !this.data.selectShow1
  });
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/type',//php/方法
    data:{
      type:self.data.type1,
      time:self.data.time1,
    },
    method: 'GET',
    header: {
      'content-type': 'application/json'
    },
    success: function (res) {
      for (var i=0;i<res.data.length;i++){
        var img1 = res.data[i]['img'].split('|')
        var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        res.data[i]['img']=img1
        res.data[i]['datatime']=time3      
      }
        self.setData({
          list:res.data,
        });
    },
  })
},
// 点击下拉显示框
select() {
  this.setData({
    Show: !this.data.Show
  });
},
select1() {
  this.setData({
    Show1: !this.data.Show1
  });
},
// 点击下拉列表
option(e) {
  var self = this;
  let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
  this.setData({
    time: Index,
    Show: !this.data.Show
  });
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Huiyinglie/type',//php/方法
    data:{
      time:self.data.time,
      type:self.data.type,
    },
    method: 'GET',
    header: {
      'content-type': 'application/json'
    },
    success: function (res) {
        self.setData({
          list1:res.data,
        });
    },
  })
},
option1(e) {
  var self = this;
  let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
  this.setData({
    time1: Index,
    Show1: !this.data.Show1
  });
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/type',//php/方法
    data:{
      time:self.data.time1,
      type:self.data.type1,
    },
    method: 'GET',
    header: {
      'content-type': 'application/json'
    },
    success: function (res) {
      for (var i=0;i<res.data.length;i++){
        var img1 = res.data[i]['img'].split('|')
        var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        res.data[i]['img']=img1
        res.data[i]['datatime']=time3      
      }
        self.setData({
          list:res.data,
        });
    },
  })
},

// 自定义事件，用来接收子组件传递的数据
handleItemChange(e){
  const {index} = e.detail;
  let {tabs} = this.data;
  tabs.forEach((v,i) =>i==index?v.isActive=true:v.isActive=false);
    
  this.setData({
    tabs
  })
},

userInput: function(e) {  
  var id=e.detail.value;//获取搜索框的内容
  clearTimeout(this.TimeId);//清除定时器     
  this.TimeId=setTimeout(()=>{//重新设置搜索时间
    if((id.length!=9)&&(id.length!=0)){
      console.log("学号错误");
    }
    else{
      this.onShow();
    }
  },1500) ; 
  this.setData({//改变id值
    id:id
  })
  let that = this;
  wx.request({
    url: 'http://localhost:90/tp5/public/Index.php/index/Guangchang/search1',
    method: 'GET',
    data: {
      id: id,
    },
    header: {
      'content-type': 'application/json'
    },    
    success(res) {
      for (var i=0;i<res.data.length;i++){
        var img1 = res.data[i]['img'].split('|')
        var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        res.data[i]['img']=img1
        res.data[i]['datatime']=time3     
      }
      that.setData({
        list: res.data
      })
    }   
  })
},



submit: function(e) {
    var index = e.currentTarget.dataset.index
    // var id = e.currentTarget.dataset.id
    this.setData({
      showModal: false,
      index,
      // id
    })
},

preventTouchMove: function() {
  this.setData({
    showModal: true
  })
},
go: function(e) { 
  var that = this
  var tie_id = e.currentTarget.dataset.tie
  this.setData({
    showModal: true
  })
  wx.request({
    url: 'http://localhost:90/tp5/public/Index.php/index/Guangchang/shanchu',
    method: 'GET',
    data: {
      tie_id: tie_id,
    },
    header: {
      'content-type': 'application/json'
    },    
    success(res) {
      for (var i=0;i<res.data.length;i++){
      var img1 = res.data[i]['img'].split('|')
      var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
      var time2=parseInt(time1/1000)
      if(time2<=3600){//分钟
        var time3=parseInt(time2/60)+"分"
      }
      else if(3600<time2&&time2<=86400){
        var time3=parseInt(time2/3600)+"时"
      }else{
        var time3=parseInt(time2/3600/24)+"天"
      }
      res.data[i]['img']=img1
      res.data[i]['datatime']=time3
    }
      that.setData({
        list: res.data
      })
    }   
  })
},
go1: function(e) { 
  var tie = e.currentTarget.dataset.tie
  wx.navigateTo({
    url: '../xiangxi/xiangxi?tie_id='+tie,
  });
},
onPullDownRefresh: function () {
  var self = this;
  this.setData({
    time:0,
    type:0,
    time1:0,
    type:0,
    biao:""
  })
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Huiyinglie/index',//php/方法
    method: 'GET',
    header: {
      'content-type': 'application/json'
    },
    success: function (res) {
        self.setData({
        list1:res.data,
      });
    },
  });
  wx.request({
    url: 'http://localhost:90/tp5/public/index.php/index/Guangchang/index',
    method:'GET',
    header:{'Content-Type':'application/json'},
    data:{},
    success:function(res){
      for (var i=0;i<res.data.length;i++){
        var img1 = res.data[i]['img'].split('|')
        var time1=Date.parse(new Date())-Date.parse(res.data[i]['datatime'])
        var time2=parseInt(time1/1000)
        if(time2<=3600){//分钟
          var time3=parseInt(time2/60)+"分"
        }
        else if(3600<time2&&time2<=86400){
          var time3=parseInt(time2/3600)+"时"
        }else{
          var time3=parseInt(time2/3600/24)+"天"
        }
        res.data[i]['img']=img1
        res.data[i]['datatime']=time3
      }
      self.setData({
        list: res.data,
      })
    },
    
  })
}
})