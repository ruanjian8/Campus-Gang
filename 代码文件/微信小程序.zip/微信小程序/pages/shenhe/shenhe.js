// pages/demo8/demo8.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
  tie_id:0,
  },
  onLoad: function (options) {
    var self = this;
    var cause = options.cause;
    var tie_id = options.tie_id;
    self.setData({
      tie_id,
      cause,
    })
  }
})