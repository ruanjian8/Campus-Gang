// pages/public/public.js
Page({
  data: {
    list:[ ],//物品数据 

  },
  onLoad:function(options){
    var openid=options.openid 
    this.setData({
      openid:openid
    })
  },
  onShow:function() {
    var self=this;  
    wx.request({
      url: 'http://localhost:90/tp5/public/Index.php/index/Issue/information',
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },       
      success:function(res){
        self.setData({
          list:res.data,
        })    
      }          
    })
  },
  onPullDownRefresh: function (){
    var self=this;  
    wx.request({
      url: 'http://localhost:90/tp5/public/Index.php/index/Issue/information',
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },       
      success:function(res){
        self.setData({
          list:res.data,
        })    
      }          
    })
  }
})