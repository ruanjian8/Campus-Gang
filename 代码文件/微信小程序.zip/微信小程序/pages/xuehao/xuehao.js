// pages/xuehao/xuehao.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid:'asd',
    qRCodeMsg:'',
    open:0,
    xian:0,
    shi:0,
    Wechat_name:"qweqwe",
    wechat_avatar:"qweqeqe"
  },
  getQRCode: function(){
    var _this = this;
    wx.scanCode({        //扫描API
      success: function(res){
        _this.setData({
          qRCodeMsg: res.result
        });
        wx.request({
          url: 'http://localhost:90/tp5/public/index.php/index/Xuehao/xinxi',//php/方法
          data:{
            sno:_this.data.qRCodeMsg
          },
          method: 'GET',
          header: {
            'content-type': 'application/json'
          },
          success: function (res) {
            if (res.data == 0){
              wx.showModal({
                title: '提示',
                content: '您已毕业，不能进行绑定。',
                showCancel:false,
                success (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  }
                }
              })
            }else if (res.data == 1){
              wx.showModal({
                title: '提示',
                content: '此学生证已经被其他微信号绑定。',
                showCancel:false,
                success (res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  }
                }
              })
            }else{
              _this.setData({
                list:res.data,
                shi:1
              });
            }
              
          },
        });
      }
    })
  },
  preventTouchMove: function() {
    this.setData({
      shi: 0
    })
  },
  shangchuan(e){
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Xuehao/cunchu',//php/方法
      data:{
        sno:this.data.qRCodeMsg,
        name : this.data.list[0].name,
        openid : this.data.openid,
        Wechat_name : this.data.Wechat_name,
        wechat_avatar : this.data.wechat_avatar,
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      
    })
    wx.showToast({
        title: '成功',
        duration: 2000
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var openid = options.openid;
    this.setData({
      openid:openid
    })
    var self = this;
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Xuehao/index',//php/方法
      data:{
        openid:self.data.openid
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        self.setData({
          xian:res.data,
        });
      }
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Xuehao/shuju',//php/方法
      data:{
        openid:self.data.openid
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      
      success: function (res) {
        self.setData({
          list:res.data,
        });
      }
    });               
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})