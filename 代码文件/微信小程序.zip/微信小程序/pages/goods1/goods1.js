// pages/goods/goods.js
Page({
  data: {
    id_1:0,//外部接收的学号，通过学号进行后台查询数据
    num: 0,//设置隐藏弹窗的初始值
    mode:0,
    list:[ ],//物品数据
    id:0
  },
  //检测页面
  onLoad:function(options) {   
    var id= options.id;
    var openid= options.openid;
    this.setData({
      id_1:id,
      openid:openid
    })
  },
  //刷新数据
  onShow:function(){
    var self=this;
    wx.request({
      url: 'http://localhost:90/tp5/public/Index.php/index/Good1/data',
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      data: {
        sno:this.data.id_1
      },   
      success:function(res){
        self.setData({
          list:res.data
        })
      }          
    })
  },
  bindletop(e){//将点击过后的值传给此函数
    const operation = e.currentTarget.dataset.operation;//读取e中的值bin传给operation
    this.setData({
      num:operation//改变值初始值
    })
  },
  bindletop1(e){//将点击过后的值传给此函数
    const operation = e.currentTarget.dataset.operation;//读取e中的值bin传给operation
    const mode = e.currentTarget.dataset.id;
    this.setData({
      num:operation,//改变值初始值
      id:mode
    })
  },
  //删除数据
  bindRemove(e){
      let id=this.data.id//获取id
      let mode=this.data.list[id].tie_id//获取帖子编号
      let name=this.data.list[id].name//获取姓名
      var that=this;
      console.log(name);
      wx.showModal({
        title: '提示',
        content: '确定要删除吗？',
        success: function (sm) {
          if (sm.confirm) {   
            wx.request({
              url: 'http://localhost:90/tp5/public/Index.php/index/Good1/delete',
              data: {
                tie_id: mode,
                openid:that.data.openid,
                sno:that.data.id_1
              },
              method: 'GET',
              header: {
                'content-type': 'application/json'
              }         
            })        
          }
          that.onShow();
        }                  
      })
      wx.request({
        url: 'http://localhost:90/tp5/public/Index.php/index/Good1/alter',
        data: {
          tie_id: mode,
        },
          method: 'GET',
          header: {
          'content-type': 'application/json'
          }         
      }) 
  }       
})