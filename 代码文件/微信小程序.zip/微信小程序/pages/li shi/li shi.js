Page({
  data: {
    selectShow: false,//控制下拉列表的显示隐藏，false隐藏、true显示
    operation:0,
    selectData: ['时间','今天','昨天','一个星期','更久'],//下拉列表的数据
    index: 0,//选择的下拉列表下标
    Show: false,//控制下拉列表的显示隐藏，false隐藏、true显示 
    Data: ['操作','删除','注销','审核'],//下拉列表的数据
    time1:0,
    time_stap:0,
    miaoshu:"最近一次登录时间",
    id:0,
    list:[ ],
    url:"/pages/lishitie/lishitie",
    url1:"",
  },
    
  
  // 点击下拉显示框
  selectTap() {
    this.setData({
      selectShow: !this.data.selectShow
    });
  },
  // 点击下拉列表
  optionTap(e) {
    var self = this;
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    self.setData({
      time1: Index,
      selectShow: !this.data.selectShow
    });

    //
    
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishi/index1',
      data: {
        time1:self.data.time1,
        operation:self.data.operation,
        sno:self.data.sno,
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    })
  },
  // 点击下拉显示框
  select() {
    this.setData({
      Show: !this.data.Show
    });
  },
  // 点击下拉列表
  option(e) {
    var self = this;
    let Index = e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    this.setData({
      operation: Index,
      Show: !this.data.Show
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishi/index1',
      data: {
        operation:self.data.operation,
        time1:self.data.time1,
        sno:self.data.sno,
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) { //页面显示
    var self = this;
    var sno = options.id;
    self.setData({
      sno
    })
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishi/time',
      data: {
        sno:sno
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list1:res.data,
        }) 
      }
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishi/caozuo',
      data: {
        sno:sno
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         self.setData({
         list:res.data,
        }) 
      }
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      time:0,
      type:0,
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishi/time',
      data: {
        sno:that.data.sno
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         that.setData({
         list1:res.data,
        }) 
      }
    });
    wx.request({
      url: 'http://localhost:90/tp5/public/index.php/index/Lishi/caozuo',
      data: {
        sno:that.data.sno
      },
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
         that.setData({
          list:res.data,
        }) 
      }
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})