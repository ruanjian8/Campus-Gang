// pages/demo7/demo7.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    voteTitle: null,//初值
    tie_id:1,//初值
    status:1,
  },
  voteTitle: function(e){//获取信息
    // this.data.voteTitle = e.detail.value;
    this.setData({
      voteTitle:e.detail.value
    })
  },
  Logbtn:function (){// 点击确定获取信息并跳转
    
    if(this.data.voteTitle==null){
      wx.showModal({
        title: '提示',
        content: '内容不能为空！',
        showCancel:false,
        success: function (sm) {
          if (sm.confirm) {
            console.log('用户点击确定')// 用户点击了确定,可以调用删除方法了
          } 
        }
      })
    }else{
      wx.request({
        url: 'http://localhost:90/tp5/public/index.php/index/Xinxi/index',
        data: {
          txt: this.data.voteTitle,
          tie_id:this.data.tie_id,
          openid:this.data.openid,
          hui_type:this.data.hui_type,
          hui_sno:this.data.hui_sno,
          sno:this.data.sno
        },//获取用户所输入的数据
        method: 'GET',
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          console.log(res.data)
          wx.showModal({
            title: '提示',
            content: res.data,
          })
        }
      })
      wx.navigateBack({
        delta:1
      })
    }
    
  },
  Log:function(){// 点击取消 跳转
    wx.navigateBack({
      delta:1
    })
  },
  onLoad: function (options) {
    var tie_id = options.tie_id;
    var hui_type = options.hui_type;
    var openid = options.openid;
    var hui_sno = options.hui_sno;
    var sno = options.sno;
    this.setData({
      tie_id,
      hui_type,
      openid,
      hui_sno,
      sno
    })
  }

})